export const nextChar = (c) => {
  return String.fromCharCode(c.charCodeAt(0) + 1);
};
